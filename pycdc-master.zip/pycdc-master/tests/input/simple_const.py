# Description:      Simple constants applicable to any Python version
# Valid Pythons:    all

# Note: Python 1.0 will insert an implied "print" statement into each line

a = 42
b = 3.14159
c = "test"
d = (1, 2)
e = (3,)
f = [1, 2]
g = {'key': 42}
