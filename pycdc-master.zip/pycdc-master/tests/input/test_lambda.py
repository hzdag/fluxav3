palette = map(lambda a: (a, a, a), range(256))
palette = map(lambda (r, g, b): chr(r) + chr(g) + chr(b), palette)
palette = map(lambda r: r, palette)
palette = lambda (r, g, b): r
palette = lambda (r): r
palette = lambda r: r
palette = (lambda (r): r, palette)
